class ConvoCreds{
  final String? senderId;
  final String? senderName;

  ConvoCreds({required this.senderId, required this.senderName});
}