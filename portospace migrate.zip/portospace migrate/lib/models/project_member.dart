class ProjectMember {
  final String memberId;
  final String memberName;
  final String memberRole;

  ProjectMember({required this.memberId, required this.memberName, required this.memberRole});
  
}